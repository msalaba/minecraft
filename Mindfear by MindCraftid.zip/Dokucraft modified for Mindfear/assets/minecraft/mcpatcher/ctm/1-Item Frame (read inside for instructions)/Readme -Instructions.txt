Drag and drop the planks_birch.png into:

C:\Users\Administrator\AppData\Roaming\.minecraft\resourcepacks\assets\minecraft\textures\blocks


This will visually alter the Item Frame to make it look better.