Dokucraft: The Saga Continues Dark

This pack requires the very latest version of 
MCPatcher for all features to function properly. 
Optifine will not work with many of the special 
additional features included in this pack.

For detailed installation instructions and general 
troubleshooting please visit owr official website or forum: 

Website:
http://dokucraft.co.uk

Forum:
http://www.minecraftforum.net/topic/513093-dokucraft-the-saga-continues/

If you'd like to use any of this work for a remix or
as a base for your own pack be sure to read and
follow 'Terms of Use' on the link above.


If you downloaded this texture pack from anywhere 
other than the dokucraft website, minecraft forum or 
dokucraft Planet Minecraft account, please inform me 
at: <dokucraft@outlook.com> You may not get a response,
but it provides me with valuable feedback to ensure
ower work isn't being illegally stolen for profit.

NOTE!
I, the creator of the map Mindfear (MindCraftid) have Dokucraft Dark creator's permission to modify this texturepack
and add sounds. Check the supplement called 'Handsome_Dan discussion' for proof.

� 2009-2013, Dokucraft: The Saga Continues <dokucraft@outlook.com>