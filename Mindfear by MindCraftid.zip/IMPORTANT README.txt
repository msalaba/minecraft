The map should automagically load the right resource pack. If it doesn't,
use the attached resource pack called "Dokucraft modified for Mindfear".

HOW TO INSTALL MAP
1. Open the .minecraft/saves map. On windows it can be found in this way:
    a) Press the "Windos button" + R combination on the keyboard.
    b) Type in %appdata% and hit ENTER
    c) Goto: .minecraft > saves
2. Drag "Mindfear by MindCraftid" into the "saves" folder.
3. Start Minecraft if you haven't.
4. Click "Singleplayer", chose Mindfear in the map list and click "Play Selected World".
You are now playing the map.

HOW TO INSTALL RESOURCE PACK (in case it doesn't install automagically)
1. 1. Open the .minecraft/resourcepacks map. On windows it can be found in this way:
    a) Press the "Windos button" + R combination on the keyboard.
    b) Type in %appdata% and hit ENTER
    c) Goto: .minecraft > resourcepacks
2. Drag "Dokucraft modified for Mindfear" into the "resourcepacks" folder.
3. Start Minecraft if you haven't.
4. Click "Options...", then "Resource Packs..."
5. Hover your mouse over "Dokucraft modified for Mindfear" and click the arrow pointing to the right.
The resource pack is now installed and you're ready to play the map.