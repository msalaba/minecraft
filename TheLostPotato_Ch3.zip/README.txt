The Lost Potato - Chapter 3:
-Secret Chambers-

by ICrafting
----------------------------------
Adventure map for minecraft 1.7.2!
----------------------------------
For 1-2 players!


INSTALL:
--------
- Copy the 'The Lost Potato (Chapter 3) by ICrafting' folder into your .minecraft/saves/ folder
- Copy the 'LPChapter3_rpack.zip' into your .minecraft/resourcepacks/ folder (And load it in minecraft afterwards)
- Set ingame music 'OFF' and Weather sounds to '30%'
- Read the rules and have fun!


SERVER SETTINGS: 
*********************************************************
DO NOT USE BUKKIT SERVER!!! Host/play it on only vanilla! 
*********************************************************

COPY/REPLACE these lines in your server.properties file in order to run the map:

enable-command-block=true
defaultgamemode=2
commandBlockOutput=false
doTileDrops=false
doMobLoot=false
mobGriefing=false
spawn-monsters=false
spawn-protection=1
spawn-npcs=true
gamemode=2
spawn-animals=true
keepInventory=true
view-distance=8
difficulty=2

SPAWN-TROUBLE:
**************
If you spawn on top of the map (or some other weird place) for some reason (bug), here are the starting coordinates: -220 91 321


USE THE CUSTOMIZED RESOURCE PACK FOR THE MAP! If the textures are messed up, use mcpatcher. Don't use optifine!
***************************************************************************************************************


YouTube:
********
www.youtube.com/Indianacrafting

You can support me by commenting, liking my videos, subscribing and you can also donate on paypal, if you really appreciate what I do. :)



